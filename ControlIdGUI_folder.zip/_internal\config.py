#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuración del sistema ControlId.
Este archivo se genera automáticamente desde la GUI de configuración.
"""

# Configuración MiID (MySQL)
MIID_CONFIG = {
    "host": "miidsqldev.mysql.database.azure.com",
    "port": 3306,
    "user": "Wilfran.Rivera",
    "password": "zi4i1WFBpRX8*Bytte",
    "database": "miidcore"
}

# Configuración Azure SQL (BykeeperDesarrollo)
AZURE_CONFIG = {
    "servidor": "inspruebas.database.windows.net",
    "base_datos": "ByKeeper_Desarrollo",
    "usuario": "MonitorOp",
    "contraseña": "zi3i1WFBpRX8*Bytte",
    "stored_procedure": "dbo.GetMatchIDImgFaceByCASBid",
    "business_context": "MatchId"
}

# Configuración ControlId
CONTROL_ID_CONFIG = {
    "base_url": "http://192.168.3.37",
    "login": "admin",
    "password": "admin"
}

# Configuración de carpetas
CARPETAS_CONFIG = {
    "carpeta_local_temp": r"C:/temp",
    "extension_imagen": ".jpg"
}
